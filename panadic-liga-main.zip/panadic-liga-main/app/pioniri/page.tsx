import LeagueView from "@/components/LeagueView";

export default function PioniriPage() {
  return (
    <div className="p-4">
      <LeagueView leagueCode="PIONIRI" />
    </div>
  );
}
