import LeagueView from "@/components/LeagueView";

export default function MladjiPioniriPage() {
  return (
    <div className="p-4">
      <LeagueView leagueCode="MLADJI" />
    </div>
  );
}
